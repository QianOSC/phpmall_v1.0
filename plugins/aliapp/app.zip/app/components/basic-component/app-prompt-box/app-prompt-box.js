;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/basic-component/app-prompt-box/app-prompt-box"],{"1f26":function(t,n,e){"use strict";var o=e("2a7e"),r=e.n(o);r.a},"285b":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={name:"app-prompt-box",props:{text:{type:String}},methods:{close:function(t){this.$emit("click",t)}}};n.default=o},"287f":function(t,n,e){"use strict";e.r(n);var o=e("285b"),r=e.n(o);for(var u in o)"default"!==u&&function(t){e.d(n,t,function(){return o[t]})}(u);n["default"]=r.a},"2a7e":function(t,n,e){},"387a":function(t,n,e){"use strict";e.r(n);var o=e("93ed"),r=e("287f");for(var u in r)"default"!==u&&function(t){e.d(n,t,function(){return r[t]})}(u);e("1f26");var a=e("2877"),c=Object(a["a"])(r["default"],o["a"],o["b"],!1,null,"39a6e7f4",null);n["default"]=c.exports},"93ed":function(t,n,e){"use strict";var o=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return o}),e.d(n,"b",function(){return r})}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/basic-component/app-prompt-box/app-prompt-box-create-component',
    {
        'components/basic-component/app-prompt-box/app-prompt-box-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("387a"))
        })
    },
    [['components/basic-component/app-prompt-box/app-prompt-box-create-component']]
]);                
