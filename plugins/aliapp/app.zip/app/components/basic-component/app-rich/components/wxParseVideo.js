;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/basic-component/app-rich/components/wxParseVideo"],{"1e21":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"wxParseVideo",props:{node:{}}};e.default=r},"26a1":function(n,e,t){"use strict";t.r(e);var r=t("1e21"),u=t.n(r);for(var a in r)"default"!==a&&function(n){t.d(e,n,function(){return r[n]})}(a);e["default"]=u.a},"9b8f":function(n,e,t){"use strict";var r=function(){var n=this,e=n.$createElement;n._self._c},u=[];t.d(e,"a",function(){return r}),t.d(e,"b",function(){return u})},b9a8:function(n,e,t){"use strict";t.r(e);var r=t("9b8f"),u=t("26a1");for(var a in u)"default"!==a&&function(n){t.d(e,n,function(){return u[n]})}(a);var o=t("2877"),c=Object(o["a"])(u["default"],r["a"],r["b"],!1,null,null,null);e["default"]=c.exports}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/basic-component/app-rich/components/wxParseVideo-create-component',
    {
        'components/basic-component/app-rich/components/wxParseVideo-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("b9a8"))
        })
    },
    [['components/basic-component/app-rich/components/wxParseVideo-create-component']]
]);                
