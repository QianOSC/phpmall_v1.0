;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/goods/bd-flash-sale"],{"0b5e":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"bd-flash-sale",props:{flashSale:{type:Object,default:function(){return{time_status:1,start_at:"",end_at:"",min_discount:""}}},theme:Object},methods:{navigator:function(){t.navigateTo({url:this.flashSale.url})}}};n.default=e}).call(this,e("c11b")["default"])},"28dc":function(t,n,e){"use strict";e.r(n);var a=e("0b5e"),u=e.n(a);for(var c in a)"default"!==c&&function(t){e.d(n,t,function(){return a[t]})}(c);n["default"]=u.a},3247:function(t,n,e){"use strict";var a=e("b024"),u=e.n(a);u.a},"7dd8":function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return u})},"975a":function(t,n,e){"use strict";e.r(n);var a=e("7dd8"),u=e("28dc");for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);e("3247");var r=e("2877"),o=Object(r["a"])(u["default"],a["a"],a["b"],!1,null,"3c433e70",null);n["default"]=o.exports},b024:function(t,n,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-flash-sale-create-component',
    {
        'components/page-component/goods/bd-flash-sale-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("975a"))
        })
    },
    [['components/page-component/goods/bd-flash-sale-create-component']]
]);                
