;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/cats/cats-image"],{"1e69":function(t,n,e){"use strict";e.r(n);var a=e("8e5c"),u=e("c25f");for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);e("c0a8");var i=e("2877"),r=Object(i["a"])(u["default"],a["a"],a["b"],!1,null,"779c2be4",null);n["default"]=r.exports},"6de3":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"cats-image",props:{theme:String},data:function(){return{is_loading:!1}},methods:{imgLoad:function(){this.is_loading=!0}}};n.default=a},"864f":function(t,n,e){},"8e5c":function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return u})},c0a8:function(t,n,e){"use strict";var a=e("864f"),u=e.n(a);u.a},c25f:function(t,n,e){"use strict";e.r(n);var a=e("6de3"),u=e.n(a);for(var c in a)"default"!==c&&function(t){e.d(n,t,function(){return a[t]})}(c);n["default"]=u.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/cats/cats-image-create-component',
    {
        'pages/cats/cats-image-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1e69"))
        })
    },
    [['pages/cats/cats-image-create-component']]
]);                
