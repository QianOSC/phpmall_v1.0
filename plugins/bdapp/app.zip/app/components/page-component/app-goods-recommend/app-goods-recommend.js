(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-goods-recommend/app-goods-recommend"],{"22eb":function(e,t,n){"use strict";var o=n("e063"),r=n.n(o);r.a},"74cd":function(e,t,n){"use strict";var o=function(){var e=this,t=e.$createElement;e._self._c},r=[];n.d(t,"a",function(){return o}),n.d(t,"b",function(){return r})},"76be":function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(){return n.e("components/page-component/u-goods-list/u-ordinary-list").then(n.bind(null,"24ba"))},r={name:"app-goods-recommend",components:{uOrdinaryList:o},props:{goodsList:Array,theme:String,sureCart:Boolean,activity:Object,is_show_member:{type:Boolean,default:function(){return!0}},sign:String,detail:Object},computed:{themeObject:function(){return{back:this.theme+"-m-back "+this.theme,theme:this.theme,color:this.theme+"-m-text "+this.theme,sBack:this.theme+"-s-back "+this.theme}}}};t.default=r},"80e1":function(e,t,n){"use strict";n.r(t);var o=n("76be"),r=n.n(o);for(var a in o)"default"!==a&&function(e){n.d(t,e,function(){return o[e]})}(a);t["default"]=r.a},"8e97":function(e,t,n){"use strict";n.r(t);var o=n("74cd"),r=n("80e1");for(var a in r)"default"!==a&&function(e){n.d(t,e,function(){return r[e]})}(a);n("22eb");var c=n("2877"),i=Object(c["a"])(r["default"],o["a"],o["b"],!1,null,"11c6a0e6",null);t["default"]=i.exports},e063:function(e,t,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-goods-recommend/app-goods-recommend-create-component',
    {
        'components/page-component/app-goods-recommend/app-goods-recommend-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("8e97"))
        })
    },
    [['components/page-component/app-goods-recommend/app-goods-recommend-create-component']]
]);                
