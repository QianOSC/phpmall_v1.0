(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-order-goods-info/app-order-goods-info"],{1602:function(t,n,e){"use strict";e.r(n);var a=e("4c67"),o=e("9c56");for(var u in o)"default"!==u&&function(t){e.d(n,t,function(){return o[t]})}(u);e("d3f6");var r=e("2877"),f=Object(r["a"])(o["default"],a["a"],a["b"],!1,null,"5195cb61",null);n["default"]=f.exports},3276:function(t,n,e){},"4c67":function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},o=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return o})},"5a2d":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-order-goods-info",data:function(){return{}},props:{goods:{type:Object,default:{}},plugin:{type:String,default:""},isLastOne:{type:Boolean,default:!0},pluginData:{type:Object,default:{}},pluginIndex:{type:Number,default:0}}};n.default=a},"9c56":function(t,n,e){"use strict";e.r(n);var a=e("5a2d"),o=e.n(a);for(var u in a)"default"!==u&&function(t){e.d(n,t,function(){return a[t]})}(u);n["default"]=o.a},d3f6:function(t,n,e){"use strict";var a=e("3276"),o=e.n(a);o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-order-goods-info/app-order-goods-info-create-component',
    {
        'components/page-component/app-order-goods-info/app-order-goods-info-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("1602"))
        })
    },
    [['components/page-component/app-order-goods-info/app-order-goods-info-create-component']]
]);                
