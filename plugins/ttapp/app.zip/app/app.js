
require('./common/runtime.js')
require('./common/vendor.js')
require('./common/main.js')

// 不要删这行注释，微擎版用的：siteInfo: require('siteinfo.js')
