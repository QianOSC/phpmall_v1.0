(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-diy-goods-list/app-diy-composition-image"],{"715b":function(e,t,n){},"8bae":function(e,t,n){"use strict";var o=function(){var e=this,t=e.$createElement;e._self._c},a=[];n.d(t,"a",function(){return o}),n.d(t,"b",function(){return a})},"92f0":function(e,t,n){"use strict";n.r(t);var o=n("8bae"),a=n("a297");for(var r in a)"default"!==r&&function(e){n.d(t,e,function(){return a[e]})}(r);n("f7e1");var i=n("2877"),u=Object(i["a"])(a["default"],o["a"],o["b"],!1,null,"35b064d2",null);t["default"]=u.exports},a297:function(e,t,n){"use strict";n.r(t);var o=n("ad3b"),a=n.n(o);for(var r in o)"default"!==r&&function(e){n.d(t,e,function(){return o[e]})}(r);t["default"]=a.a},ad3b:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o={name:"app-diy-composition-image",props:{imageList:Array,mode:String},computed:{imageClass:function(){var e=this.imageList.length;switch(e){case 1:return"goods-one";case 2:return"goods-two";case 3:return"goods-three";case 4:return"goods-four";case 5:return"goods-five"}}}};t.default=o},f7e1:function(e,t,n){"use strict";var o=n("715b"),a=n.n(o);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-diy-goods-list/app-diy-composition-image-create-component',
    {
        'components/page-component/app-diy-goods-list/app-diy-composition-image-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("92f0"))
        })
    },
    [['components/page-component/app-diy-goods-list/app-diy-composition-image-create-component']]
]);                
