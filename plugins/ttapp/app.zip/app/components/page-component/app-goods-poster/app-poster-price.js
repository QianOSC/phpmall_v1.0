(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-goods-poster/app-poster-price"],{"06f9":function(n,t,e){},"0708":function(n,t,e){"use strict";var o=e("06f9"),r=e.n(o);r.a},2e3:function(n,t,e){"use strict";e.r(t);var o=e("3eb7"),r=e.n(o);for(var a in o)"default"!==a&&function(n){e.d(t,n,function(){return o[n]})}(a);t["default"]=r.a},"3eb7":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(){return e.e("components/page-component/goods/app-price").then(e.bind(null,"6c9f"))},r={components:{appPrice:o},props:{whiteColor:Boolean,info:Object,textColor:{type:String,default:"#FF4544"}},data:function(){return{defaultPrice:["booking","","miaosha","mch","pick"]}}};t.default=r},"52d2":function(n,t,e){"use strict";var o=function(){var n=this,t=n.$createElement,e=(n._self._c,n.defaultPrice.indexOf(n.info.sign));n.$mp.data=Object.assign({},{$root:{g0:e}})},r=[];e.d(t,"a",function(){return o}),e.d(t,"b",function(){return r})},b30d:function(n,t,e){"use strict";e.r(t);var o=e("52d2"),r=e("2000");for(var a in r)"default"!==a&&function(n){e.d(t,n,function(){return r[n]})}(a);e("0708");var u=e("2877"),c=Object(u["a"])(r["default"],o["a"],o["b"],!1,null,"5e2e9508",null);t["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-goods-poster/app-poster-price-create-component',
    {
        'components/page-component/app-goods-poster/app-poster-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("b30d"))
        })
    },
    [['components/page-component/app-goods-poster/app-poster-price-create-component']]
]);                
